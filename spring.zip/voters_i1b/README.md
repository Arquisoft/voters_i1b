Voters
======

Voters Subsystem

[![Build Status](https://travis-ci.org/Arquisoft/voters_i1b.svg?branch=master)](https://travis-ci.org/Arquisoft/voters_i1b)

Authors
=======
* Daniel Cuesta
* Andrei Manu
* Carlos Suárez




